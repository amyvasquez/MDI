﻿Public Class dinero

End Class